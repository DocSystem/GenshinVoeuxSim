import wishes
import random

curr = 0
curr_pity5 = 0
curr_pity4 = 0
pities5 = wishes.get_5stars()
pities4 = wishes.get_4stars()

while True:
    for i in range(10):
        curr += 1
        curr_pity5 += 1
        curr_pity4 += 1
        luck = random.randint(0, 100)
        if luck <= pities5[curr_pity5 - 1]["percentage"]:
            print(str(curr) + ". 5 stars - Pity : " + str(curr_pity5))
            curr_pity5 = 0
        elif luck <= pities4[curr_pity4 - 1]["percentage"]:
            print(str(curr) + ". 4 stars - Pity : " + str(curr_pity5))
            curr_pity4 = 0
        else:
            print(str(curr) + ". 3 stars - Pity : " + str(curr_pity5))
    input()
